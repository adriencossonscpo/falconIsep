

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */ 
public enum FormType
{
	PERSONALISABLE, ROTI;
}
