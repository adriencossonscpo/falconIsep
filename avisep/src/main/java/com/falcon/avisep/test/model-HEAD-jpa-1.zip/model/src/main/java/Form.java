
import java.util.HashSet;
import java.util.Set;



/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */
 
@javax.persistence.Entity 
public class Form
{
	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Enumerated(javax.persistence.EnumType.STRING) 
	@javax.persistence.Column 
	protected FormType formType;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.OneToOne 
	protected UserAvis createdBy;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.Column 
	protected String dateCreation;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToMany(mappedBy = "form") 
	protected Set<Template> template;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToMany(mappedBy = "form") 
	protected Set<Question> question;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	 
	@javax.persistence.ManyToOne 
	@javax.persistence.JoinColumn(nullable = false) 
	protected UserAvis userAvis;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	@javax.persistence.Id 
	@javax.persistence.Column(nullable = false) 
	protected final Long id = 0L;

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 */
	public Form(){
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void basicSetUserAvis(UserAvis myUserAvis) {
		if (this.userAvis != myUserAvis) {
			if (myUserAvis != null){
				if (this.userAvis != myUserAvis) {
					UserAvis olduserAvis = this.userAvis;
					this.userAvis = myUserAvis;
					if (olduserAvis != null)
						olduserAvis.removeForm(this);
				}
			}
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public FormType getFormType() {
		return this.formType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public UserAvis getCreatedBy() {
		return this.createdBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public String getDateCreation() {
		return this.dateCreation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Set<Template> getTemplate() {
		if(this.template == null) {
				this.template = new HashSet<Template>();
		}
		return (Set<Template>) this.template;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public Set<Question> getQuestion() {
		if(this.question == null) {
				this.question = new HashSet<Question>();
		}
		return (Set<Question>) this.question;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public UserAvis getUserAvis() {
		return this.userAvis;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public long getId() {
		return this.id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllTemplate(Set<Template> newTemplate) {
		if (this.template == null) {
			this.template = new HashSet<Template>();
		}
		for (Template tmp : newTemplate)
			tmp.addForm(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addAllQuestion(Set<Question> newQuestion) {
		if (this.question == null) {
			this.question = new HashSet<Question>();
		}
		for (Question tmp : newQuestion)
			tmp.addForm(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllTemplate(Set<Template> newTemplate) {
		if(this.template == null) {
			return;
		}
		
		this.template.removeAll(newTemplate);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeAllQuestion(Set<Question> newQuestion) {
		if(this.question == null) {
			return;
		}
		
		this.question.removeAll(newQuestion);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setFormType(FormType myFormType) {
		this.formType = myFormType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setCreatedBy(UserAvis myCreatedBy) {
		this.createdBy = myCreatedBy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setDateCreation(String myDateCreation) {
		this.dateCreation = myDateCreation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addTemplate(Template newTemplate) {
		if(this.template == null) {
			this.template = new HashSet<Template>();
		}
		
		if (this.template.add(newTemplate))
			newTemplate.addForm(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void addQuestion(Question newQuestion) {
		if(this.question == null) {
			this.question = new HashSet<Question>();
		}
		
		if (this.question.add(newQuestion))
			newQuestion.addForm(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void setUserAvis(UserAvis myUserAvis) {
		this.basicSetUserAvis(myUserAvis);
		myUserAvis.addForm(this);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetFormType() {
		this.formType = null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetCreatedBy() {
		this.createdBy = null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetDateCreation() {
		this.dateCreation = null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeTemplate(Template oldTemplate) {
		if(this.template == null)
			return;
		
		if (this.template.remove(oldTemplate))
			oldTemplate.removeForm(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void removeQuestion(Question oldQuestion) {
		if(this.question == null)
			return;
		
		if (this.question.remove(oldQuestion))
			oldQuestion.removeForm(this);
		
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!--  end-user-doc  -->
	 * @generated
	 * @ordered
	 */
	public void unsetUserAvis() {
		if (this.userAvis == null)
			return;
		UserAvis olduserAvis = this.userAvis;
		this.userAvis = null;
		olduserAvis.removeForm(this);
	}

}

