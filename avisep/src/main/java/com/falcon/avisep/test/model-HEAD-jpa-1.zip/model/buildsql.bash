#!/bin/bash
mvn clean compile hibernate3:hbm2ddl

