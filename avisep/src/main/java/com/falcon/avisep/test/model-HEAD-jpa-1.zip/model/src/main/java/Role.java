

/**
 * <!-- begin-user-doc -->
 * <!--  end-user-doc  -->
 * @generated
 */ 
public enum Role
{
	Student, ETeacher, VTeacher, AdminAvis;
}
